# v0.1.12
## 09/28/2019

1. [](#bugfix)
    * Fix changelog date formatting
    
# v0.1.11
## 09/22/2019

1. [](#bugfix)
    * Remove hardcoded admin paths from report URLs
    
# v0.1.10
## 10/10/2018

1. [](#bugfix)
    * Add beta version in dependency util
    
# v0.1.9
## 06/22/2018

1. [](#bugfix)
    * Update CSS styling for section editor - Fixes issues with update messages.

# v0.1.8
## 06/22/2018

1. [](#bugfix)
    * Update CSS styling for section editor - Fixes issues with update messages.

# v0.1.7
## 06/12/2018

1. [](#bugfix)
    * Make Save+Back asynchronous

# v0.1.6
## 06/12/2018

1. [](#new)
    * Add syntax highlight support for section editor
    
# v0.1.5
## 06/12/2018

1. [](#feature)
    * Add a Save+Back command to the section editor
    
2. [](#task)
    * Refactor section editor actions

# v0.1.4
## 04/11/2018

1. [](#bugfix)
    * Catch exceptions in version check 

# v0.1.3
## 03/29/2018

1. [](#bugfix)
    * Use correct parameter order for startsWith()

# v0.1.2
## 03/29/2018

1. [](#bugfix)
    * Fix reference to utility function startsWith()
    
# v0.1.1
## 03/26/2018

1. [](#new)
    * Add options to enable move_page and rename_page
    
2. [](#bugfix)
    * Move missing getPages() twig extension function into plugin    
    
# v0.1.0
## 03/25/2018

1. [](#new)
    * Initial commit
