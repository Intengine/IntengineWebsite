#!/bin/sh
scss --watch scss:css-compiled --style compressed
